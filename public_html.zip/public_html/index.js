const dados = require('./data/dados.json')
const express = require('express')
const fs = require('fs')
const cors = require('cors')

const server = express()
server.use(cors())
server.use(express.json())

server.listen(3000, () => {
    console.log("O servidor está funcional");
})

server.get('/', (req, res) => {
    return res.json({ mensagem: "Estou funcionando!" })
})

// CRUD DA API

// Create da API
server.post('/usuarios', (req, res) => {
    const { nome, idade, curso } = req.body

    if (!nome || !idade || !curso) {
        return res.status(400).json({ mensagem: "Dados incompletos, tente novamente" })
    } else {
        const novoUsuario = {
            id: dados.Usuarios.length + 1,
            nome: nome,
            idade: idade,
            curso: curso
        }

        dados.Usuarios.push(novoUsuario)
        salvarDados(dados)

        return res.status(201).json({ mensagem: "Dados completos, cadastro de usuário feito com sucesso!" })
    }
})

// Read da API
server.get('/usuarios', (req, res) => {
    return res.json(dados.Usuarios)
})

// Update da API
server.put('/usuarios/:id', (req, res) => {
    const usuarioId = parseInt(req.params.id);
    const { nome, idade, curso } = req.body;

    const indiceUsuario = dados.Usuarios.findIndex(u => u.id === usuarioId);

    if (indiceUsuario === -1) {
        return res.status(404).json({ mensagem: "Usuário não encontrado" });
    } else {
        dados.Usuarios[indiceUsuario].nome = nome || dados.Usuarios[indiceUsuario].nome;
        dados.Usuarios[indiceUsuario].idade = idade || dados.Usuarios[indiceUsuario].idade;
        dados.Usuarios[indiceUsuario].curso = curso || dados.Usuarios[indiceUsuario].curso;

        salvarDados();

        return res.status(200).json({ mensagem: "Usuário atualizado com sucesso" });
    }
});

// Delete da API
server.delete('/usuarios/:id', (req, res) => {
    const usuarioId = parseInt(req.params.id);

    dados.Usuarios = dados.Usuarios.filter(u => u.id !== usuarioId);

    salvarDados();

    return res.status(200).json({ mensagem: "Usuário excluído com sucesso" });
});

// Função que salva os dados
function salvarDados() {
    fs.writeFileSync(__dirname + './data/dados.json', JSON.stringify(dados, null, 2))
}

module.exports = {dados}