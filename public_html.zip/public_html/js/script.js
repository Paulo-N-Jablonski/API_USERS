const userForm = document.getElementById('user-form');
const userList = document.getElementById('user-list');

function listUsers() {
    fetch('http://localhost:3000/usuarios')
        .then(response => response.json())
        .then(data => {
            userList.innerHTML = '';
            data.forEach(user => {
                const li = document.createElement('li');
                li.innerHTML = `${user.nome} - Idade: ${user.idade} - Curso: ${user.curso} `;
                userList.appendChild(li);

                const deleteButton = document.createElement('button');
                deleteButton.innerText = 'Deletar';
                deleteButton.addEventListener('click', () => deleteUser(user.id));
                li.appendChild(deleteButton);

                const putButton = document.createElement('button');
                putButton.innerText = 'Alterar';
                putButton.addEventListener('click', () => putUser(user.id));
                li.appendChild(putButton);
            });
        })
        .catch(error => console.error('Erro:', error));
}

userForm.addEventListener('submit', (e) => {
    e.preventDefault();

    const name = document.getElementById('name').value;
    const age = document.getElementById('age').value;
    const course = document.getElementById('course').value;
    console.log("cheguei")
    fetch('http://localhost:3000/usuarios', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ nome: name, idade: age, curso: course }),
    })
        .then(response => response.json())
        console.log("cheguei 2")
        .then(() => {
            console.log("cheguei 3")
            listUsers();
            userForm.reset();
        })
        .catch(error => console.error('Erro:', error));
});

function deleteUser(userId) {
    fetch(`http://localhost:3000/usuarios/${userId}`, {
        method: 'DELETE',
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao excluir usuário');
            }
            return response.json();
        })
        .then(() => {
            listUsers();
        })
        .catch(error => console.error('Erro ao excluir usuário:', error));
}

function putUser(userId) {
    const nome = document.getElementById('name').value;
    const idade = document.getElementById('age').value;
    const curso = document.getElementById('course').value;

    if (nome.trim() === '' && idade.trim() === '' && curso.trim() === '') {
        alert('Por favor, preencha todos os campos antes de fazer a alteração.');
        return;
    }

    fetch(`http://localhost:3000/usuarios/${userId}`, {
        method: 'PUT',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ id: userId, nome: nome, idade: idade, curso: curso }),
    })
        .then(response => {
            if (!response.ok) {
                throw new Error('Erro ao atualizar usuário');
            }
            return response.json();
        })
        .then(() => {
            listUsers();
        })
        .catch(error => console.error('Erro ao atualizar usuário:', error));
}

listUsers();